package global

const (
	ProductIndexName                     = "shop-product"
	OrderIndexName                       = "shop-order"
	SearchLogDbName                      = "shop"
	ProductSearchLogCollectionNamePrefix = "product_search_%d"
	OderSearchLogCollectionNamePrefix    = "order_search_%d"
)
